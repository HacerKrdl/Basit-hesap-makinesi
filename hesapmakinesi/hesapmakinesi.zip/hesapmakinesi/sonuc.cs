﻿namespace hesapmakinesi
{
    internal class sonuc
    {
    }
}