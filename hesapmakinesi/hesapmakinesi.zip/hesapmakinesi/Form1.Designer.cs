﻿
namespace hesapmakinesi
{
    partial class hesapmakinesi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelekran = new System.Windows.Forms.Label();
            this.rakam0_button = new System.Windows.Forms.Button();
            this.rakam3_button = new System.Windows.Forms.Button();
            this.rakam2_button = new System.Windows.Forms.Button();
            this.rakam1_button = new System.Windows.Forms.Button();
            this.rakam6_button = new System.Windows.Forms.Button();
            this.rakam5_button = new System.Windows.Forms.Button();
            this.rakam4_button = new System.Windows.Forms.Button();
            this.rakam9_button = new System.Windows.Forms.Button();
            this.rakam8_button = new System.Windows.Forms.Button();
            this.rakam7_button = new System.Windows.Forms.Button();
            this.kosinus_button = new System.Windows.Forms.Button();
            this.sinus_button = new System.Windows.Forms.Button();
            this.bolu1_button = new System.Windows.Forms.Button();
            this.kare_button = new System.Windows.Forms.Button();
            this.esittir_button = new System.Windows.Forms.Button();
            this.toplama_button = new System.Windows.Forms.Button();
            this.cıkarma_button = new System.Windows.Forms.Button();
            this.carpma_button = new System.Windows.Forms.Button();
            this.bolme_button = new System.Windows.Forms.Button();
            this.sil_button = new System.Windows.Forms.Button();
            this.gecmis_button = new System.Windows.Forms.Button();
            this.kök_button = new System.Windows.Forms.Button();
            this.groupbox = new System.Windows.Forms.GroupBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tanjant_button = new System.Windows.Forms.Button();
            this.kotanjant_button = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupbox.SuspendLayout();
            this.SuspendLayout();
            // 
            // labelekran
            // 
            this.labelekran.BackColor = System.Drawing.SystemColors.Window;
            this.labelekran.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelekran.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelekran.Location = new System.Drawing.Point(10, 30);
            this.labelekran.Name = "labelekran";
            this.labelekran.Size = new System.Drawing.Size(463, 104);
            this.labelekran.TabIndex = 0;
            this.labelekran.Text = "0";
            this.labelekran.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // rakam0_button
            // 
            this.rakam0_button.BackColor = System.Drawing.Color.White;
            this.rakam0_button.Location = new System.Drawing.Point(91, 518);
            this.rakam0_button.Name = "rakam0_button";
            this.rakam0_button.Size = new System.Drawing.Size(75, 67);
            this.rakam0_button.TabIndex = 2;
            this.rakam0_button.Text = "0";
            this.rakam0_button.UseVisualStyleBackColor = false;
            this.rakam0_button.Click += new System.EventHandler(this.rakam0_button_Click);
            // 
            // rakam3_button
            // 
            this.rakam3_button.BackColor = System.Drawing.Color.White;
            this.rakam3_button.Location = new System.Drawing.Point(172, 445);
            this.rakam3_button.Name = "rakam3_button";
            this.rakam3_button.Size = new System.Drawing.Size(75, 67);
            this.rakam3_button.TabIndex = 6;
            this.rakam3_button.Text = "3";
            this.rakam3_button.UseVisualStyleBackColor = false;
            this.rakam3_button.Click += new System.EventHandler(this.rakam3_button_Click);
            // 
            // rakam2_button
            // 
            this.rakam2_button.BackColor = System.Drawing.Color.White;
            this.rakam2_button.Location = new System.Drawing.Point(91, 445);
            this.rakam2_button.Name = "rakam2_button";
            this.rakam2_button.Size = new System.Drawing.Size(75, 67);
            this.rakam2_button.TabIndex = 5;
            this.rakam2_button.Text = "2";
            this.rakam2_button.UseVisualStyleBackColor = false;
            this.rakam2_button.Click += new System.EventHandler(this.rakam2_button_Click);
            // 
            // rakam1_button
            // 
            this.rakam1_button.BackColor = System.Drawing.Color.White;
            this.rakam1_button.Location = new System.Drawing.Point(10, 445);
            this.rakam1_button.Name = "rakam1_button";
            this.rakam1_button.Size = new System.Drawing.Size(75, 67);
            this.rakam1_button.TabIndex = 4;
            this.rakam1_button.Text = "1";
            this.rakam1_button.UseVisualStyleBackColor = false;
            this.rakam1_button.Click += new System.EventHandler(this.rakam1_button_Click);
            // 
            // rakam6_button
            // 
            this.rakam6_button.BackColor = System.Drawing.Color.White;
            this.rakam6_button.Location = new System.Drawing.Point(172, 372);
            this.rakam6_button.Name = "rakam6_button";
            this.rakam6_button.Size = new System.Drawing.Size(75, 67);
            this.rakam6_button.TabIndex = 9;
            this.rakam6_button.Text = "6";
            this.rakam6_button.UseVisualStyleBackColor = false;
            this.rakam6_button.Click += new System.EventHandler(this.rakam6_button_Click);
            // 
            // rakam5_button
            // 
            this.rakam5_button.BackColor = System.Drawing.Color.White;
            this.rakam5_button.Location = new System.Drawing.Point(91, 372);
            this.rakam5_button.Name = "rakam5_button";
            this.rakam5_button.Size = new System.Drawing.Size(75, 67);
            this.rakam5_button.TabIndex = 8;
            this.rakam5_button.Text = "5";
            this.rakam5_button.UseVisualStyleBackColor = false;
            this.rakam5_button.Click += new System.EventHandler(this.rakam5_button_Click);
            // 
            // rakam4_button
            // 
            this.rakam4_button.BackColor = System.Drawing.Color.White;
            this.rakam4_button.Location = new System.Drawing.Point(10, 372);
            this.rakam4_button.Name = "rakam4_button";
            this.rakam4_button.Size = new System.Drawing.Size(75, 67);
            this.rakam4_button.TabIndex = 7;
            this.rakam4_button.Text = "4";
            this.rakam4_button.UseVisualStyleBackColor = false;
            this.rakam4_button.Click += new System.EventHandler(this.rakam4_button_Click);
            // 
            // rakam9_button
            // 
            this.rakam9_button.BackColor = System.Drawing.Color.White;
            this.rakam9_button.Location = new System.Drawing.Point(172, 299);
            this.rakam9_button.Name = "rakam9_button";
            this.rakam9_button.Size = new System.Drawing.Size(75, 67);
            this.rakam9_button.TabIndex = 12;
            this.rakam9_button.Text = "9";
            this.rakam9_button.UseVisualStyleBackColor = false;
            this.rakam9_button.Click += new System.EventHandler(this.rakam9_button_Click);
            // 
            // rakam8_button
            // 
            this.rakam8_button.BackColor = System.Drawing.Color.White;
            this.rakam8_button.Location = new System.Drawing.Point(91, 299);
            this.rakam8_button.Name = "rakam8_button";
            this.rakam8_button.Size = new System.Drawing.Size(75, 67);
            this.rakam8_button.TabIndex = 11;
            this.rakam8_button.Text = "8";
            this.rakam8_button.UseVisualStyleBackColor = false;
            this.rakam8_button.Click += new System.EventHandler(this.rakam8_button_Click);
            // 
            // rakam7_button
            // 
            this.rakam7_button.BackColor = System.Drawing.Color.White;
            this.rakam7_button.Location = new System.Drawing.Point(10, 299);
            this.rakam7_button.Name = "rakam7_button";
            this.rakam7_button.Size = new System.Drawing.Size(75, 67);
            this.rakam7_button.TabIndex = 10;
            this.rakam7_button.Text = "7";
            this.rakam7_button.UseVisualStyleBackColor = false;
            this.rakam7_button.Click += new System.EventHandler(this.rakam7_button_Click);
            // 
            // kosinus_button
            // 
            this.kosinus_button.BackColor = System.Drawing.Color.Pink;
            this.kosinus_button.Location = new System.Drawing.Point(91, 226);
            this.kosinus_button.Name = "kosinus_button";
            this.kosinus_button.Size = new System.Drawing.Size(75, 67);
            this.kosinus_button.TabIndex = 14;
            this.kosinus_button.Text = "cos";
            this.kosinus_button.UseVisualStyleBackColor = false;
            this.kosinus_button.Click += new System.EventHandler(this.kosinus_button_Click);
            // 
            // sinus_button
            // 
            this.sinus_button.BackColor = System.Drawing.Color.Pink;
            this.sinus_button.Location = new System.Drawing.Point(10, 226);
            this.sinus_button.Name = "sinus_button";
            this.sinus_button.Size = new System.Drawing.Size(75, 67);
            this.sinus_button.TabIndex = 13;
            this.sinus_button.Text = "sin";
            this.sinus_button.UseVisualStyleBackColor = false;
            this.sinus_button.Click += new System.EventHandler(this.sinus_button_Click);
            // 
            // bolu1_button
            // 
            this.bolu1_button.BackColor = System.Drawing.Color.Pink;
            this.bolu1_button.Location = new System.Drawing.Point(172, 153);
            this.bolu1_button.Name = "bolu1_button";
            this.bolu1_button.Size = new System.Drawing.Size(75, 67);
            this.bolu1_button.TabIndex = 17;
            this.bolu1_button.Text = "1/x";
            this.bolu1_button.UseVisualStyleBackColor = false;
            this.bolu1_button.Click += new System.EventHandler(this.bolu1_button_Click);
            // 
            // kare_button
            // 
            this.kare_button.BackColor = System.Drawing.Color.Pink;
            this.kare_button.Location = new System.Drawing.Point(172, 226);
            this.kare_button.Name = "kare_button";
            this.kare_button.Size = new System.Drawing.Size(75, 67);
            this.kare_button.TabIndex = 16;
            this.kare_button.Text = "x²";
            this.kare_button.UseVisualStyleBackColor = false;
            this.kare_button.Click += new System.EventHandler(this.kare_button_Click);
            // 
            // esittir_button
            // 
            this.esittir_button.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.esittir_button.Location = new System.Drawing.Point(270, 518);
            this.esittir_button.Name = "esittir_button";
            this.esittir_button.Size = new System.Drawing.Size(203, 67);
            this.esittir_button.TabIndex = 22;
            this.esittir_button.Text = "=";
            this.esittir_button.UseVisualStyleBackColor = false;
            this.esittir_button.Click += new System.EventHandler(this.esittir_button_Click);
            // 
            // toplama_button
            // 
            this.toplama_button.BackColor = System.Drawing.Color.Pink;
            this.toplama_button.Location = new System.Drawing.Point(270, 445);
            this.toplama_button.Name = "toplama_button";
            this.toplama_button.Size = new System.Drawing.Size(203, 67);
            this.toplama_button.TabIndex = 23;
            this.toplama_button.Text = "+";
            this.toplama_button.UseVisualStyleBackColor = false;
            this.toplama_button.Click += new System.EventHandler(this.toplama_button_Click);
            // 
            // cıkarma_button
            // 
            this.cıkarma_button.BackColor = System.Drawing.Color.Pink;
            this.cıkarma_button.Location = new System.Drawing.Point(270, 372);
            this.cıkarma_button.Name = "cıkarma_button";
            this.cıkarma_button.Size = new System.Drawing.Size(203, 67);
            this.cıkarma_button.TabIndex = 24;
            this.cıkarma_button.Text = "-";
            this.cıkarma_button.UseVisualStyleBackColor = false;
            this.cıkarma_button.Click += new System.EventHandler(this.cıkarma_button_Click);
            // 
            // carpma_button
            // 
            this.carpma_button.BackColor = System.Drawing.Color.Pink;
            this.carpma_button.Location = new System.Drawing.Point(270, 299);
            this.carpma_button.Name = "carpma_button";
            this.carpma_button.Size = new System.Drawing.Size(203, 67);
            this.carpma_button.TabIndex = 25;
            this.carpma_button.Text = "x";
            this.carpma_button.UseVisualStyleBackColor = false;
            this.carpma_button.Click += new System.EventHandler(this.carpma_button_Click);
            // 
            // bolme_button
            // 
            this.bolme_button.BackColor = System.Drawing.Color.Pink;
            this.bolme_button.Location = new System.Drawing.Point(270, 226);
            this.bolme_button.Name = "bolme_button";
            this.bolme_button.Size = new System.Drawing.Size(203, 67);
            this.bolme_button.TabIndex = 26;
            this.bolme_button.Text = "/";
            this.bolme_button.UseVisualStyleBackColor = false;
            this.bolme_button.Click += new System.EventHandler(this.bolme_button_Click);
            // 
            // sil_button
            // 
            this.sil_button.BackColor = System.Drawing.Color.Red;
            this.sil_button.Location = new System.Drawing.Point(270, 153);
            this.sil_button.Name = "sil_button";
            this.sil_button.Size = new System.Drawing.Size(203, 67);
            this.sil_button.TabIndex = 27;
            this.sil_button.Text = "C";
            this.sil_button.UseVisualStyleBackColor = false;
            this.sil_button.Click += new System.EventHandler(this.sil_button_Click);
            // 
            // gecmis_button
            // 
            this.gecmis_button.BackColor = System.Drawing.Color.Gray;
            this.gecmis_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.gecmis_button.Location = new System.Drawing.Point(9, 518);
            this.gecmis_button.Name = "gecmis_button";
            this.gecmis_button.Size = new System.Drawing.Size(76, 67);
            this.gecmis_button.TabIndex = 28;
            this.gecmis_button.Text = "geçmiş";
            this.gecmis_button.UseVisualStyleBackColor = false;
            this.gecmis_button.Click += new System.EventHandler(this.gecmis_button_Click);
            // 
            // kök_button
            // 
            this.kök_button.BackColor = System.Drawing.Color.Pink;
            this.kök_button.Location = new System.Drawing.Point(172, 518);
            this.kök_button.Name = "kök_button";
            this.kök_button.Size = new System.Drawing.Size(75, 67);
            this.kök_button.TabIndex = 29;
            this.kök_button.Text = "√";
            this.kök_button.UseVisualStyleBackColor = false;
            this.kök_button.Click += new System.EventHandler(this.kök_button_Click);
            // 
            // groupbox
            // 
            this.groupbox.Controls.Add(this.listBox1);
            this.groupbox.Location = new System.Drawing.Point(490, 30);
            this.groupbox.Name = "groupbox";
            this.groupbox.Size = new System.Drawing.Size(283, 555);
            this.groupbox.TabIndex = 31;
            this.groupbox.TabStop = false;
            this.groupbox.Text = "Geçmiş";
            this.groupbox.Visible = false;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 29;
            this.listBox1.Location = new System.Drawing.Point(7, 33);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(233, 497);
            this.listBox1.TabIndex = 0;
            this.listBox1.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(12, 94);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 29);
            this.label1.TabIndex = 32;
            // 
            // tanjant_button
            // 
            this.tanjant_button.BackColor = System.Drawing.Color.Pink;
            this.tanjant_button.Location = new System.Drawing.Point(10, 153);
            this.tanjant_button.Name = "tanjant_button";
            this.tanjant_button.Size = new System.Drawing.Size(75, 67);
            this.tanjant_button.TabIndex = 33;
            this.tanjant_button.Text = "tan";
            this.tanjant_button.UseVisualStyleBackColor = false;
            this.tanjant_button.Click += new System.EventHandler(this.tanjant_button_Click);
            // 
            // kotanjant_button
            // 
            this.kotanjant_button.BackColor = System.Drawing.Color.Pink;
            this.kotanjant_button.Location = new System.Drawing.Point(91, 153);
            this.kotanjant_button.Name = "kotanjant_button";
            this.kotanjant_button.Size = new System.Drawing.Size(75, 67);
            this.kotanjant_button.TabIndex = 34;
            this.kotanjant_button.Text = "cot";
            this.kotanjant_button.UseVisualStyleBackColor = false;
            this.kotanjant_button.Click += new System.EventHandler(this.kotanjant_button_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(11, 105);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 29);
            this.label2.TabIndex = 35;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 1);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 29);
            this.label3.TabIndex = 36;
            // 
            // hesapmakinesi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(481, 591);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.kotanjant_button);
            this.Controls.Add(this.tanjant_button);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupbox);
            this.Controls.Add(this.kök_button);
            this.Controls.Add(this.gecmis_button);
            this.Controls.Add(this.sil_button);
            this.Controls.Add(this.bolme_button);
            this.Controls.Add(this.carpma_button);
            this.Controls.Add(this.cıkarma_button);
            this.Controls.Add(this.toplama_button);
            this.Controls.Add(this.esittir_button);
            this.Controls.Add(this.bolu1_button);
            this.Controls.Add(this.kare_button);
            this.Controls.Add(this.kosinus_button);
            this.Controls.Add(this.sinus_button);
            this.Controls.Add(this.rakam9_button);
            this.Controls.Add(this.rakam8_button);
            this.Controls.Add(this.rakam7_button);
            this.Controls.Add(this.rakam6_button);
            this.Controls.Add(this.rakam5_button);
            this.Controls.Add(this.rakam4_button);
            this.Controls.Add(this.rakam3_button);
            this.Controls.Add(this.rakam2_button);
            this.Controls.Add(this.rakam1_button);
            this.Controls.Add(this.rakam0_button);
            this.Controls.Add(this.labelekran);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Margin = new System.Windows.Forms.Padding(5);
            this.MaximizeBox = false;
            this.Name = "hesapmakinesi";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.groupbox.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelekran;
        private System.Windows.Forms.Button rakam0_button;
        private System.Windows.Forms.Button rakam3_button;
        private System.Windows.Forms.Button rakam2_button;
        private System.Windows.Forms.Button rakam1_button;
        private System.Windows.Forms.Button rakam6_button;
        private System.Windows.Forms.Button rakam5_button;
        private System.Windows.Forms.Button rakam4_button;
        private System.Windows.Forms.Button rakam9_button;
        private System.Windows.Forms.Button rakam8_button;
        private System.Windows.Forms.Button rakam7_button;
        private System.Windows.Forms.Button kosinus_button;
        private System.Windows.Forms.Button sinus_button;
        private System.Windows.Forms.Button bolu1_button;
        private System.Windows.Forms.Button kare_button;
        private System.Windows.Forms.Button esittir_button;
        private System.Windows.Forms.Button toplama_button;
        private System.Windows.Forms.Button cıkarma_button;
        private System.Windows.Forms.Button carpma_button;
        private System.Windows.Forms.Button bolme_button;
        private System.Windows.Forms.Button sil_button;
        private System.Windows.Forms.Button gecmis_button;
        private System.Windows.Forms.Button kök_button;
        private System.Windows.Forms.GroupBox groupbox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button tanjant_button;
        private System.Windows.Forms.Button kotanjant_button;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}

